import random


def zad8(hasla):
    haslo=hasla[random.randint(0, len(hasla))]
    litery=[]
    litery2=[]
    gra=False
    for litera in haslo:
        litery.append(litera)
        litery2.append(False)
    
    while gra==False:
        show=""
        for i in range(0, len(litery)):
            if litery2[i]==True:
                show += litery[i]
            else:
                show += "_"
        print(show)
        wybor=input("Podaj znak: ")
        if wybor==" ":
            slowo=input("Podaj cale slowo: ")
            if slowo==haslo:
                break
            else:
                print("Bledna odpowiedz, probuj ponownie")
        for i in range(len(litery)):
            if litery[i]== wybor:
                litery2[i]=True
        gra=True
        for stan in litery2:
            if stan==False:
                gra=False
    print("Haslo:", haslo)

hasla=['abc', 'def', 'xyz']
zad8(hasla)