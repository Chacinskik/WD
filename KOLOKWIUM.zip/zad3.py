def zad3(x,y, wartosc=0):
    lista=[]
    s=0
    k=y
    for i in range(x):
        if i!=0:
            print(lista[s:k])
            s+=y
            k+=y
        for i in range(y):
            lista.append(wartosc)
    print(lista[0:y])
    return lista


zad3(4,3, 2)