def zad5(tekst):
    tekst2=tekst.split('.')
    dlugosc=len(tekst2)-1
    dlugosc3=0
    for i in range(len(tekst2)-1):
        tekst3=tekst2[i].split()
        dlugosc2=len(tekst3)
        if (dlugosc2>dlugosc3):
            dlugosc3=len(tekst3)
    
    print("W tekscie jest {} zdan".format(dlugosc))
    print("Najdluzsze zdanie ma {} wyrazow".format(dlugosc3))

tekst="Jestem. Sobie ja. I robie zadanka. O tak."

zad5(tekst)