lista=[(2*x)/3 for x in range(1,21,1)]
print(lista)