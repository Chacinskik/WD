def zad2(tekst):
    lista=[]
    tekst2=tekst.split('.')
    for zdanie in tekst2:
        tekst3=zdanie.split()
        if (zdanie != ""):
            lista.append(zdanie)
    lista.sort(key=lambda x: len(x.split()))
    return lista
        


   
tekst="Jestem. Sobie ja. I robie zadanka. O tak."

print(zad2(tekst))
