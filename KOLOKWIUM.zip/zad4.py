def zad4(n, symbol):
    if n%2==1:
        for i in range((n//2)+1):
            print(i*'_' + symbol)
        for i in range((n//2)-1, -1, -1):
            print(i*'_' + symbol)

zad4(13, 'o')